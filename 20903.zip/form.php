<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>PHP+MySQL 입문</title>
<link rel="stylesheet" href="style.css">
<script>
function check_input() {
    if(!document.board.name.value) {
        alert("이름을 입력하세요!");
        document.board.pass.focus();
        return;
    }
    if(!document.board.subject.value) {
        alert("제목을 입력하세요!");
        document.board.subject.value.focus();
        return;
    }

    document.board.submit();
}
</script>
</head>
<body>
    <h2>자유 게시판 > 글쓰기</h2>
    <form name="board" method="post" action="insert.php">
    <ul class="board_form">
    <li>
        <span class="col1">이름 : </span>
        <span class="col2"><input name ="name" type="text">
        </span>
    </li></ul>
</body>
</html>